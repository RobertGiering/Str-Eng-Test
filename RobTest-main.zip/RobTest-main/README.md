# Sterling Engine Audio Thermometer

![image](https://user-images.githubusercontent.com/20614666/195118759-dceea372-b688-4d0a-9da6-a8e887f73c0a.png)
